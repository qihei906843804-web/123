% RESUME_FIG5_LOCAL 修复验证程序后，从已保存的 20 mT 结果继续。
% 本脚本不调用 shooting_solver，不重复第一步 e0 全区间搜索。
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'source'));
clear validate_single_case reproduce_fig5a;

runDir=uigetdir(root,'请选择包含 shooting_20mT.mat 的 rerun_fig5 文件夹');
if isequal(runDir,0), return; end
baseline=fullfile(runDir,'shooting_20mT.mat');
assert(exist(baseline,'file')==2,'所选目录中没有 shooting_20mT.mat。');
S=load(baseline,'p','r');
assert(isfield(S,'p') && isfield(S,'r'),'基线文件缺少 p 或 r。');
p=S.p;
assert(~isempty(S.r.solutions),'基线文件没有已求得的分支。');

convergenceDir=fullfile(runDir,'convergence');
convergenceFile=fullfile(convergenceDir,'convergence.mat');
if exist(convergenceFile,'file')==2
    C=load(convergenceFile,'report'); report=C.report;
    fprintf('读取已有完整验证结果：%s\n',convergenceFile);
else
    if exist(convergenceDir,'dir')
        convergenceDir=fullfile(runDir,['convergence_resumed_' datestr(now,'yyyymmdd_HHMMSS')]);
        convergenceFile=fullfile(convergenceDir,'convergence.mat');
    end
    fprintf('从第二步继续验证，不重复第一步全区间搜索。\n');
    report=validate_single_case(p,baseline,convergenceDir);
end

% 只在独立副本中调整路径，不改原源文件或控制方程。
txt=fileread(fullfile(root,'source','reproduce_fig5a.m'));
oldPath='''/workspace/beam-results/fig5_convergence_complete/convergence.mat''';
assert(contains(txt,oldPath),'源文件的加载路径与预期不同，请保留报错信息。');
newPath=['''' strrep(convergenceFile,'''','''''') ''''];
txt=strrep(txt,oldPath,newPath);
adapterDir=fullfile(runDir,['local_adapter_' datestr(now,'yyyymmdd_HHMMSS')]);
assert(~exist(adapterDir,'dir'),'适配目录已存在，请稍后重试。');
mkdir(adapterDir);
fid=fopen(fullfile(adapterDir,'reproduce_fig5a.m'),'w','n','UTF-8');
assert(fid>=0,'无法写入本地路径适配程序。');
fprintf(fid,'%s',txt); fclose(fid);
addpath(adapterDir,'-begin');
clear reproduce_fig5a;

sweepDir=fullfile(runDir,['sweep_resumed_' datestr(now,'yyyymmdd_HHMMSS')]);
sweep=reproduce_fig5a(sweepDir);
assert(all([sweep.cases.converged]),'部分磁场未收敛；请保留命令窗口输出和 sweep 记录。');
handles=plot_fig5a(sweep,fullfile(sweepDir,'figures'));
files=export_fig5_png(fullfile(sweepDir,'sweep.mat'),fullfile(sweepDir,'png300'));
fprintf('\n完成！新结果目录：\n%s\n',sweepDir);
