function report = validate_single_case(p, baseline_path, output_dir)
%VALIDATE_SINGLE_CASE 单工况输出网格与 ODE 容差验证，保留历史结果。
% 输入：可选 p、已保存 shooting MAT 路径、独立输出目录。
% 输出：report，双分支、输出网格、积分容差及原方程诊断结果。
% 输出网格用 ode45 的原生连续输出，不使用额外 pchip 插值。
% 在 Octave 中另行用单输出 ode45 获取真正自适应接受网格，
% 比较 RHS 次数及终点，确认输出点设置没有改变积分过程。
% E_kappa 归一化为 E_kappa/max(max|kappa|,1/L)。
% 中心线与势能使用论文运动学和能量公式，稳定性不在本检查中判定。
if nargin<1, p=parameters(); end
if nargin<2, baseline_path='/workspace/beam-results/fig5_20mT_shooting.mat'; end
if nargin<3, output_dir='/workspace/beam-results/fig5_convergence'; end
if exist(output_dir,'dir')
    error('HardMagneticBeam:PreserveResults', ...
        '输出目录已存在；请选择新目录以保留全部计算结果。');
end
baseline=load(baseline_path,'r');
branches=baseline.r.solutions;
if isempty(branches), error('HardMagneticBeam:NoBranches','没有已保存的分支。'); end
p.C01=p.G/2; p.I=p.b*p.h^3/12;
timer=tic;
grid_cases=struct([]); tolerance_cases=struct([]);
for b=1:numel(branches)
    seed=branches(b).free_state(2:3);
    [e0,root_info]=refine(branches(b).e0,seed,1e-8,1e-10);
    base=integrate(e0,seed,1e-8,1e-10,[]);
    for N=[101,201,401,801]
        t=tic;
        run=integrate(e0,seed,1e-8,1e-10,N);
        run=diagnose(run,base,N,root_info);
        run.branch=branches(b).branch;
        run.elapsed_seconds=toc(t);
        % MATLAB 不允许向无字段的 struct([]) 按整结构下标赋值。
        % 第一条记录建立字段结构，后续记录保持同一字段集合。
        if isempty(grid_cases)
            grid_cases=run;
        else
            grid_cases(end+1,1)=run; %#ok<AGROW>
        end
        print_row('grid',run);
    end
    for level=1:2
        rels=[1e-6,1e-8]; abss=[1e-8,1e-10];
        t=tic;
        [e0,root_info]=refine(branches(b).e0,seed,rels(level),abss(level));
        base=integrate(e0,seed,rels(level),abss(level),[]);
        run=integrate(e0,seed,rels(level),abss(level),801);
        run=diagnose(run,base,801,root_info);
        run.branch=branches(b).branch;
        run.elapsed_seconds=toc(t);
        if isempty(tolerance_cases)
            tolerance_cases=run;
        else
            tolerance_cases(end+1,1)=run; %#ok<AGROW>
        end
        print_row('tolerance',run);
    end
end
report=struct('parameters',p,'baseline_path',baseline_path, ...
    'grid_cases',grid_cases,'tolerance_cases',tolerance_cases, ...
    'elapsed_seconds',toc(timer),'displacement_available',true, ...
    'energy_available',true,'stability_assessed',false);
mkdir(output_dir);
save(fullfile(output_dir,'convergence.mat'),'report','-v7');
export_rows(fullfile(output_dir,'grid.csv'),grid_cases);
export_rows(fullfile(output_dir,'tolerances.csv'),tolerance_cases);
fprintf('总验证时间 %.6f s；位移和势能已计算，稳定性尚未评估。\n', ...
    report.elapsed_seconds);

    function [e0,info]=refine(initial,seed,rel,abs_tol)
        calls=0;
        left=initial-1e-5; right=initial+1e-5;
        left=max(left,p.e0_range(1)); right=min(right,p.e0_range(2));
        fl=boundary(left); fr=boundary(right);
        if fl*fr>0
            error('HardMagneticBeam:NoLocalBracket','已有分支附近没有边界变号区间。');
        end
        [e0,value,flag]=fzero(@boundary,[left,right],optimset('TolX',1e-12));
        if flag<=0 || abs(value)>1e-7
            error('HardMagneticBeam:RootRefinement','边界根细化失败：flag=%d, Rc=%g。',flag,abs(value));
        end
        info=struct('flag',flag,'Rc',abs(value),'calls',calls, ...
            'root_tolerance',1e-12);
        function value=boundary(e)
            run=integrate(e,seed,rel,abs_tol,[]);
            value=run.y(end,3)+p.k*run.y(end,2); calls=calls+1;
        end
    end

    function run=integrate(e0,seed,rel,abs_tol,N)
        local=p; local.newton_initial=seed;
        [f,info,flag]=solve_free_end(e0,local);
        if flag~=1
            error('HardMagneticBeam:RefinementNewton','自由端 Newton 失败：%s。',info.message);
        end
        initial=[f.e;f.gamma_tilde;f.theta;0];
        calls=0; ode_identity=0;
        opts=odeset('RelTol',rel,'AbsTol',abs_tol,'MaxStep',p.L/10);
        if isempty(N)
            sol=ode45(@rhs,[p.L,0],initial,opts);
            x=sol.x(:); y=sol.y';
        else
            [x,y]=ode45(@rhs,linspace(p.L,0,N),initial,opts);
        end
        if x(end)~=0 || any(~isfinite(y(:))) || any(y(:,1)<=0)
            error('HardMagneticBeam:ValidationIntegration','积分未完成或状态无效。');
        end
        run=struct('e0',e0,'x',x,'y',y,'newton_info',info, ...
            'rel_tol',rel,'abs_tol',abs_tol,'rhs_calls',calls, ...
            'ode_stage_identity_max',ode_identity);
        function dy=rhs(x,y)
            dy=beam_ode(x,y,p); calls=calls+1;
            ode_identity=max(ode_identity,abs(dy(3)-y(4)));
        end
    end

    function run=diagnose(run,base,N,root_info)
        run.output_nodes=N;
        run.internal_steps=numel(base.x)-1;
        run.internal_x=base.x; run.internal_y=base.y;
        run.same_rhs_calls=(run.rhs_calls==base.rhs_calls);
        run.endpoint_difference=max(abs(run.y(end,:)-base.y(end,:)));
        if ~run.same_rhs_calls || run.endpoint_difference>1e-10
            error('HardMagneticBeam:GridChangedIntegration', ...
                '输出网格改变了实际积分过程，不能作为纯输出网格比较。');
        end
        run.diagnostics=beam_residuals(run.x,run.y,p);
        run.internal_diagnostics=beam_residuals(base.x,base.y,p);
        run.Rc=abs(run.y(end,3)+p.k*run.y(end,2));
        run.theta_L=run.y(1,3); run.gamma_L=run.y(1,2);
        run.tip_angle=run.theta_L+p.k*run.gamma_L;
        run.free_end_kappa_error=abs(run.y(1,4));
        run.E_kappa=run.diagnostics.compatibility_max;
        run.E_kappa_normalized=run.E_kappa/max(max(abs(run.y(:,4))),1/p.L);
        run.integral_compatibility_max=max(abs(base.y(:,3)-base.y(1,3) ...
            -cumtrapz(base.x,base.y(:,4))));
        run.root_info=root_info;
        run.shape=postprocess_shape(run.x,run.y(:,1),run.y(:,2),run.y(:,3),p);
        run.energy=energy_evaluation(run.x,run.y(:,1),run.y(:,2),run.y(:,3),run.y(:,4),p);
        run.v_L_over_L=run.shape.v_L_over_L; run.U=run.energy.Utotal;
    end
end

function print_row(kind,r)
fprintf('%s %s N=%d: Rc=%.5g, e0=%.12g, thetaL=%.9g, gammaL=%.9g, E=%g, Erel=%g, steps=%d, RHS=%d, time=%.3fs\n', ...
    kind,r.branch,r.output_nodes,r.Rc,r.e0,r.theta_L,r.gamma_L,r.E_kappa, ...
    r.E_kappa_normalized,r.internal_steps,r.rhs_calls,r.elapsed_seconds);
fprintf('  vL/L=%.12g, phiL=%.12g rad, Us=%.12g J, Um=%.12g J, U=%.12g J\n', ...
    r.v_L_over_L,r.tip_angle,r.energy.Us,r.energy.Um,r.U);
end

function export_rows(path,rows)
fid=fopen(path,'w');
if fid<0, error('HardMagneticBeam:ExportFailure','无法创建 %s。',path); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'branch,N,RelTol,AbsTol,e0,theta_L,gamma_L,Rc,v_L_over_L,U,E_kappa,E_kappa_normalized,internal_steps,rhs_calls,time_seconds,tip_angle,R34_relative,R35_relative,R36_relative,internal_R34_relative,internal_R35_relative,internal_R36_relative,ode_stage_identity,free_end_kappa_error,integral_compatibility_error,Us,Um\n');
for j=1:numel(rows)
 r=rows(j);
 fprintf(fid,'%s,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%d,%d,%.6f,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g\n', ...
 r.branch,r.output_nodes,r.rel_tol,r.abs_tol,r.e0,r.theta_L,r.gamma_L,r.Rc, ...
 r.v_L_over_L,r.U,r.E_kappa,r.E_kappa_normalized,r.internal_steps,r.rhs_calls, ...
 r.elapsed_seconds,r.tip_angle,r.diagnostics.max_relative, ...
 r.internal_diagnostics.max_relative,r.ode_stage_identity_max,r.free_end_kappa_error, ...
 r.integral_compatibility_max,r.energy.Us,r.energy.Um);
end
end
