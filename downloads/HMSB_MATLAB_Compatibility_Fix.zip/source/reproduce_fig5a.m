function sweep = reproduce_fig5a(output_dir, resume_path)
%REPRODUCE_FIG5A 已验证模型的单参数磁场延拓，保留两条弯曲分支。
% 输入：新输出目录；默认 /workspace/beam-results/fig5a_sweep。
% 输出：sweep，各工况状态、轨迹、残差、失败原因和延拓试探记录。
% 以已验证20mT解为锚点，向低场和高场延拓；不声称分支稳定或唯一。
% Ba=0 单独采用未变形参考解，不通过退化 Newton 构造假解。
if nargin==0, output_dir='/workspace/beam-results/fig5a_sweep'; end
if exist(output_dir,'dir')
    error('HardMagneticBeam:PreserveResults','输出目录存在，请指定新目录。');
end
p=parameters(); p.C01=p.G/2; p.I=p.b*p.h^3/12;
saved=load('/workspace/beam-results/fig5_convergence_complete/convergence.mat','report');
anchor=saved.report.grid_cases([4,8]);
fields=[0,5,10,15,20,25,30,35,40];
cases=repmat(empty_case(),numel(fields),2); history=struct([]);
previous_failures=struct([]);
if nargin>=2 && ~isempty(resume_path)
    prior=load(resume_path,'sweep');
    if ~isequal(prior.sweep.fields_mT,fields)
        error('HardMagneticBeam:ResumeFields','恢复数据的磁场列表不匹配。');
    end
    cases=prior.sweep.cases; history=prior.sweep.history;
    previous_failures=cases(~[cases.converged]);
end
timer=tic; mkdir(output_dir);
for branch=1:2
    if cases(1,branch).converged && cases(5,branch).converged, continue; end
    reference_timer=tic;
    local=p; local.B_a=0;
    y=[ones(801,1),zeros(801,3)]; x=linspace(p.L,0,801)';
    cases(1,branch)=finalize(local,0,branch,1,x,y,0,0);
    cases(1,branch).elapsed_seconds=toc(reference_timer);
    a=anchor(branch);
    local=p; local.B_a=0.02;
    t=tic; [x,y,info]=integrate(local,a.e0,[a.gamma_L;a.theta_L],true);
    cases(5,branch)=finalize(local,20,branch,a.e0,x,y,toc(t),info.rhs_calls);
end
% 每条分支的低、高场序列均从已验证锚点开始。
for direction=1:2
    if direction==1, sequence=[4,3,2]; else, sequence=[6,7,8,9]; end
    previous=cases(5,:);
    for index=sequence
        for branch=1:2
            if cases(index,branch).converged
                previous(branch)=cases(index,branch);
                continue;
            end
            local=p; local.B_a=fields(index)*1e-3; t=tic;
            try
                seed=[previous(branch).gamma_L;previous(branch).theta_L];
                guess=1+(previous(branch).e0-1)*fields(index)/previous(branch).Ba_mT;
                % 对称负分支首先尝试正分支的 e0，但轨迹独立 Newton/ODE 求解。
                if branch==2 && cases(index,1).converged
                    guess=cases(index,1).e0;
                end
                [e0,root_calls]=find_root(local,guess,seed,branch,fields(index));
                [x,y,info]=integrate(local,e0,seed,true);
                candidate=finalize(local,fields(index),branch,e0,x,y,toc(t),info.rhs_calls);
                candidate.root_calls=root_calls;
                cases(index,branch)=candidate;
                if candidate.converged
                    previous(branch)=candidate;
                end
            catch exception
                candidate=empty_case(); candidate.Ba_mT=fields(index);
                candidate.Ba_T=local.B_a; candidate.branch=branch;
                candidate.failure_reason=exception.message;
                candidate.elapsed_seconds=toc(t); cases(index,branch)=candidate;
            end
            c=cases(index,branch);
            fprintf('Ba=%g mT branch=%d: converged=%d, e0=%.12g, Rc=%g, v/L=%g, time=%.2fs\n', ...
                c.Ba_mT,branch,c.converged,c.e0,c.Rc,c.v_L_over_L,c.elapsed_seconds);
            if ~c.converged, fprintf('  原因：%s\n',c.failure_reason); end
            checkpoint=struct('parameters',p,'fields_mT',fields,'cases',cases,'history',history);
            save(fullfile(output_dir,'checkpoint.mat'),'checkpoint','-v7');
        end
    end
end
sweep=struct('parameters',p,'fields_mT',fields,'cases',cases,'history',history, ...
    'elapsed_seconds',toc(timer),'experimental_validation',false, ...
    'stability_assessed',false,'output_nodes',801,'RelTol',1e-8,'AbsTol',1e-10, ...
    'previous_failures',previous_failures);
save(fullfile(output_dir,'sweep.mat'),'sweep','-v7');
export_csv(sweep,output_dir);
fprintf('总时间 %.3fs；理论复现，未作实验误差比较或稳定性判定。\n',sweep.elapsed_seconds);

    function [e0,calls]=find_root(local,guess,seed,branch,Ba_mT)
        calls=0; values=[]; residuals=[];
        % 接近已收敛 e0 时优先复用，不重复扫描另一条对称支。
        [v,ok]=evaluate(guess);
        if ok && abs(v)<1e-7, e0=guess; return; end
        M=local.B_r*local.B_a/local.mu0;
        % 由自由端方程的 theta+k*gamma=0/pi 两端构造本工况搜索尺度。
        low=fzero(@(e) local.C01*(2*e-2*e^(-2))+M,[0.95,1]);
        high=fzero(@(e) local.C01*(2*e-2*e^(-2))-M,[1,1.05]);
        center=(guess-low)/(high-low);
        fractions=[center+[-.001,.001,-.003,.003,-.008,.008], ...
            .9999,.99999,.999999,center+[-.015,.015,-.04,.04,-.1,.1,-.2,.2,-.4,.4], ...
            linspace(.001,.999,17)];
        fractions=fractions(fractions>1e-10 & fractions<1-1e-10);
        bracket=[];
        for fraction=fractions
            evaluate(low+fraction*(high-low));
            [sorted,order]=sort(values); r=residuals(order);
            crossing=find(r(1:end-1).*r(2:end)<0);
            if ~isempty(crossing)
                % 优先追踪距延拓预测最近的变号区间，而不自动切换分支。
                [~,which]=min(abs((sorted(crossing)+sorted(crossing+1))/2-guess));
                j=crossing(which); bracket=[sorted(j),sorted(j+1)]; break;
            end
        end
        if isempty(bracket)
            error('HardMagneticBeam:ContinuationBracket', ...
                'Ba=%g mT 分支%d未找到有效变号区间，失败试探已记录。',Ba_mT,branch);
        end
        [e0,value,flag]=fzero(@required_value,bracket,optimset('TolX',1e-14));
        if flag<=0 || abs(value)>1e-7
            error('HardMagneticBeam:ContinuationRoot','根细化失败 flag=%d, Rc=%g。',flag,abs(value));
        end

        function [value,ok]=evaluate(e)
            calls=calls+1; value=NaN; ok=false;
            trial=struct('Ba_mT',Ba_mT,'branch',branch,'e0',e, ...
                'success',false,'signed_Rc',NaN,'seed',seed,'failure_reason','');
            try
                [~,y,~]=integrate(local,e,seed,false);
                if (branch==1 && (y(1,3)<=0 || y(1,3)>=pi)) ...
                        || (branch==2 && (y(1,3)>=0 || y(1,3)<=-pi))
                    error('HardMagneticBeam:BranchChanged','自由端转角离开追踪的弯曲分支。');
                end
                value=y(end,3)+local.k*y(end,2); ok=true;
                values(end+1)=e; residuals(end+1)=value;
                trial.success=true; trial.signed_Rc=value;
            catch exception
                trial.failure_reason=exception.message;
            end
            if isempty(history)
                history=trial;
            else
                history(end+1,1)=trial;
            end
        end
        function value=required_value(e)
            [value,ok]=evaluate(e);
            if ~ok
                error('HardMagneticBeam:ContinuationEvaluation', ...
                    '根求解中试探 e0=%.12g 失败；见 history。',e);
            end
        end
    end
end

function [x,y,info]=integrate(p,e0,seed,dense)
p.newton_initial=seed;
[f,ninfo,flag]=solve_free_end(e0,p);
if flag~=1, error('HardMagneticBeam:ContinuationNewton','Newton 失败：%s。',ninfo.message); end
opts=odeset('RelTol',1e-8,'AbsTol',1e-10,'MaxStep',p.L/10);
calls=0;
if dense
    [x,y]=ode45(@rhs,linspace(p.L,0,801),[f.e;f.gamma_tilde;f.theta;0],opts);
else
    sol=ode45(@rhs,[p.L,0],[f.e;f.gamma_tilde;f.theta;0],opts);
    x=sol.x(:); y=sol.y';
end
if x(end)~=0 || any(~isfinite(y(:))) || any(y(:,1)<=0)
    error('HardMagneticBeam:ContinuationIntegration','ODE 积分提前结束或状态无效。');
end
info=struct('rhs_calls',calls,'newton',ninfo);
    function dy=rhs(x,y)
        calls=calls+1;
        if calls>10000, error('HardMagneticBeam:ODELimit','RHS 调用超过上限。'); end
        dy=beam_ode(x,y,p);
    end
end

function c=finalize(p,Ba,branch,e0,x,y,time,calls)
c=empty_case(); c.Ba_mT=Ba; c.Ba_T=p.B_a; c.branch=branch;
c.e0=e0; c.x=x; c.y=y; c.theta_L=y(1,3); c.gamma_L=y(1,2);
c.shape=postprocess_shape(x,y(:,1),y(:,2),y(:,3),p);
c.energy=energy_evaluation(x,y(:,1),y(:,2),y(:,3),y(:,4),p);
c.phi_L=c.shape.phi_L; c.v_L_over_L=c.shape.v_L_over_L;
c.Rc=abs(y(end,3)+p.k*y(end,2)); c.diagnostics=beam_residuals(x,y,p);
c.equation_relative=c.diagnostics.max_relative;
c.converged=c.Rc<=p.Delta_c && all(c.equation_relative<1e-6);
c.elapsed_seconds=time; c.rhs_calls=calls;
if ~c.converged, c.failure_reason='固定端或原方程残差超限。'; end
end

function c=empty_case()
c=struct('Ba_mT',NaN,'Ba_T',NaN,'branch',NaN,'converged',false, ...
    'e0',NaN,'theta_L',NaN,'gamma_L',NaN,'phi_L',NaN,'v_L_over_L',NaN, ...
    'Rc',NaN,'equation_relative',[NaN,NaN,NaN],'elapsed_seconds',0, ...
    'rhs_calls',0,'root_calls',0,'failure_reason','','x',[],'y',[], ...
    'shape',[],'energy',[],'diagnostics',[]);
end

function export_csv(sweep,directory)
fid=fopen(fullfile(directory,'summary.csv'),'w'); cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'Ba_mT,Ba_T,branch,converged,e0,theta_L,gamma_L,phi_L,v_L_over_L,Rc,R34_relative,R35_relative,R36_relative,time_seconds,Us,Um,Utotal\n');
for index=1:numel(sweep.fields_mT)
 for branch=1:2
  c=sweep.cases(index,branch); energy=[NaN,NaN,NaN];
  if c.converged, energy=[c.energy.Us,c.energy.Um,c.energy.Utotal]; end
  fprintf(fid,'%.12g,%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.6f,%.12g,%.12g,%.12g\n', ...
      c.Ba_mT,c.Ba_T,c.branch,c.converged,c.e0,c.theta_L,c.gamma_L,c.phi_L, ...
      c.v_L_over_L,c.Rc,c.equation_relative,c.elapsed_seconds,energy);
  if ~c.converged, continue; end
  out=fopen(fullfile(directory,sprintf('shape_%02gmT_branch%d.csv',c.Ba_mT,branch)),'w');
  fprintf(out,'x,u,v,X,Y,phi\n'); s=c.shape;
  for j=1:numel(s.x)
   fprintf(out,'%.12g,%.12g,%.12g,%.12g,%.12g,%.12g\n',s.x(j),s.u(j),s.v(j),s.X(j),s.Y(j),s.phi(j));
  end
  fclose(out);
 end
end
end
