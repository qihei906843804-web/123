function report = diagnose_fig5_branches(output_dir)
%DIAGNOSE_FIG5_BRANCHES 保存结果分析及可疑区间小步长延拓；不改模型、不绘图。
% 输入：全新输出目录。输出：report，原网格、细化双分支、根搜索记录。
if nargin==0, output_dir='/workspace/123/results/branch_continuity'; end
if exist(output_dir,'dir'), error('输出目录存在，拒绝覆盖。'); end
mkdir(output_dir); timer=tic;
loaded=load('/workspace/beam-results/fig5a_sweep_complete/sweep.mat','sweep');
sweep=loaded.sweep; p=sweep.parameters; history=struct([]);
coarse=sweep.cases; write_table(coarse,fullfile(output_dir,'coarse_endpoints.csv'),p);
% 由原方程在 theta=gamma=kappa=0 的直梁分支上线性化。
critical=fzero(@(Ba) frequency(Ba,p)-pi/2,[.003,.005]);
critical_info=struct('Ba_mT',critical*1e3,'criterion','omega*L=pi/2', ...
    'stability_assessed',false);
sequences={ [4.75,4.5,4.25,4,3.95,3.925,3.91,3.907,3.906,3.9], ...
            [5.5,.5+5.5:0.5:10] };
refined=repmat(empty_case(),0,2);
for direction=1:2
 previous=coarse(2,:);
 for Ba=sequences{direction}
  row=repmat(empty_case(),1,2);
  for branch=1:2
   local=p; local.B_a=Ba*1e-3; t=tic;
   try
    seed=[previous(branch).gamma_L;previous(branch).theta_L];
    guess=1+(previous(branch).e0-1)*Ba/previous(branch).Ba_mT;
    if branch==2 && row(1).converged, guess=row(1).e0; end
    [e0,root_calls]=find_root(local,guess,seed,branch,Ba);
    [x,y,info]=integrate(local,e0,seed,true);
    c=finalize(local,Ba,branch,e0,x,y,toc(t),info.rhs_calls);
    c.root_calls=root_calls;
    if c.converged, previous(branch)=c; end
   catch exception
    c=empty_case(); c.Ba_mT=Ba; c.Ba_T=local.B_a; c.branch=branch;
    c.failure_reason=exception.message; c.elapsed_seconds=toc(t);
   end
   row(branch)=c;
   fprintf('fine Ba=%.6g branch=%d success=%d phi=%g v/L=%g Rc=%g time=%.2fs\n', ...
     Ba,branch,c.converged,c.phi_L,c.v_L_over_L,c.Rc,c.elapsed_seconds);
   if ~c.converged, fprintf('Reason: %s\n',c.failure_reason); end
  end
  refined(end+1,:)=row;
  checkpoint=struct('coarse',coarse,'refined',refined,'history',history,'critical',critical_info);
  save(fullfile(output_dir,'checkpoint.mat'),'checkpoint','-v7');
  if ~all([row.converged]), break; end
 end
end
% 直梁平衡单独保存：不替换任何非零弯曲分支，也不判断稳定性。
straight_fields=[0,.5,1,1.5,2,2.5,3,3.5,3.9,critical*1e3,4,5];
straight=repmat(empty_case(),numel(straight_fields),1);
for j=1:numel(straight_fields)
 local=p; local.B_a=straight_fields(j)*1e-3;
 M=local.B_r*local.B_a/local.mu0;
 es=fzero(@(e) local.C01*(2*e-2*e^(-2))+M,[.95,1.05]);
 x=linspace(local.L,0,801)'; y=[es*ones(801,1),zeros(801,3)];
 straight(j)=finalize(local,straight_fields(j),0,es,x,y,0,0);
end
report=struct('parameters',p,'coarse',coarse,'refined',refined,'history',history, ...
 'straight',straight,'critical',critical_info,'elapsed_seconds',toc(timer), ...
 'stability_assessed',false);
save(fullfile(output_dir,'continuity.mat'),'report','-v7');
write_table(refined,fullfile(output_dir,'refined_endpoints.csv'),p);
write_table(straight,fullfile(output_dir,'straight_reference.csv'),p);
fprintf('Linear marginal field %.12g mT; elapsed %.3fs\n',critical*1e3,report.elapsed_seconds);

    function [e0,calls]=find_root(local,guess,seed,branch,Ba_mT)
        calls=0; values=[]; residuals=[];
        % 接近已收敛 e0 时优先复用，不重复扫描另一条对称支。
        [v,ok]=evaluate(guess);
        if ok && abs(v)<1e-7, e0=guess; return; end
        M=local.B_r*local.B_a/local.mu0;
        % 由自由端方程的 theta+k*gamma=0/pi 两端构造本工况搜索尺度。
        low=fzero(@(e) local.C01*(2*e-2*e^(-2))+M,[0.95,1]);
        high=fzero(@(e) local.C01*(2*e-2*e^(-2))-M,[1,1.05]);
        center=(guess-low)/(high-low);
        fractions=[center+[-.001,.001,-.003,.003,-.008,.008], ...
            .000001,.00001,.0001,.001,.003,.01,.03,.9999,.99999,.999999,center+[-.015,.015,-.04,.04,-.1,.1,-.2,.2,-.4,.4], ...
            linspace(.001,.999,17)];
        fractions=fractions(fractions>1e-10 & fractions<1-1e-10);
        bracket=[];
        for fraction=fractions
            evaluate(low+fraction*(high-low));
            [sorted,order]=sort(values); r=residuals(order);
            crossing=find(r(1:end-1).*r(2:end)<0);
            if ~isempty(crossing)
                % 优先追踪距延拓预测最近的变号区间，而不自动切换分支。
                [~,which]=min(abs((sorted(crossing)+sorted(crossing+1))/2-guess));
                j=crossing(which); bracket=[sorted(j),sorted(j+1)]; break;
            end
        end
        if isempty(bracket)
            error('HardMagneticBeam:ContinuationBracket', ...
                'Ba=%g mT 分支%d未找到有效变号区间，失败试探已记录。',Ba_mT,branch);
        end
        [e0,value,flag]=fzero(@required_value,bracket,optimset('TolX',1e-14));
        if flag<=0 || abs(value)>1e-7
            error('HardMagneticBeam:ContinuationRoot','根细化失败 flag=%d, Rc=%g。',flag,abs(value));
        end

        function [value,ok]=evaluate(e)
            calls=calls+1; value=NaN; ok=false;
            trial=struct('Ba_mT',Ba_mT,'branch',branch,'e0',e, ...
                'success',false,'signed_Rc',NaN,'seed',seed,'failure_reason','');
            try
                [~,y,~]=integrate(local,e,seed,false);
                if (branch==1 && (y(1,3)<=0 || y(1,3)>=pi)) ...
                        || (branch==2 && (y(1,3)>=0 || y(1,3)<=-pi))
                    error('HardMagneticBeam:BranchChanged','自由端转角离开追踪的弯曲分支。');
                end
                value=y(end,3)+local.k*y(end,2); ok=true;
                values(end+1)=e; residuals(end+1)=value;
                trial.success=true; trial.signed_Rc=value;
            catch exception
                trial.failure_reason=exception.message;
            end
            if isempty(history)
                history=trial;
            else
                history(end+1,1)=trial;
            end
        end
        function value=required_value(e)
            [value,ok]=evaluate(e);
            if ~ok
                error('HardMagneticBeam:ContinuationEvaluation', ...
                    '根求解中试探 e0=%.12g 失败；见 history。',e);
            end
        end
    end
end
function [x,y,info]=integrate(p,e0,seed,dense)
p.newton_initial=seed;
[f,ninfo,flag]=solve_free_end(e0,p);
if flag~=1, error('HardMagneticBeam:ContinuationNewton','Newton 失败：%s。',ninfo.message); end
opts=odeset('RelTol',1e-8,'AbsTol',1e-10,'MaxStep',p.L/10);
calls=0;
if dense
    [x,y]=ode45(@rhs,linspace(p.L,0,801),[f.e;f.gamma_tilde;f.theta;0],opts);
else
    sol=ode45(@rhs,[p.L,0],[f.e;f.gamma_tilde;f.theta;0],opts);
    x=sol.x(:); y=sol.y';
end
if x(end)~=0 || any(~isfinite(y(:))) || any(y(:,1)<=0)
    error('HardMagneticBeam:ContinuationIntegration','ODE 积分提前结束或状态无效。');
end
info=struct('rhs_calls',calls,'newton',ninfo);
    function dy=rhs(x,y)
        calls=calls+1;
        if calls>10000, error('HardMagneticBeam:ODELimit','RHS 调用超过上限。'); end
        dy=beam_ode(x,y,p);
    end
end

function c=finalize(p,Ba,branch,e0,x,y,time,calls)
c=empty_case(); c.Ba_mT=Ba; c.Ba_T=p.B_a; c.branch=branch;
c.e0=e0; c.x=x; c.y=y; c.theta_L=y(1,3); c.gamma_L=y(1,2);
c.shape=postprocess_shape(x,y(:,1),y(:,2),y(:,3),p);
c.energy=energy_evaluation(x,y(:,1),y(:,2),y(:,3),y(:,4),p);
c.phi_L=c.shape.phi_L; c.v_L_over_L=c.shape.v_L_over_L;
c.Rc=abs(y(end,3)+p.k*y(end,2)); c.diagnostics=beam_residuals(x,y,p);
c.equation_relative=c.diagnostics.max_relative;
c.converged=c.Rc<=p.Delta_c && all(c.equation_relative<1e-6);
c.elapsed_seconds=time; c.rhs_calls=calls;
if ~c.converged, c.failure_reason='固定端或原方程残差超限。'; end
end

function c=empty_case()
c=struct('Ba_mT',NaN,'Ba_T',NaN,'branch',NaN,'converged',false, ...
    'e0',NaN,'theta_L',NaN,'gamma_L',NaN,'phi_L',NaN,'v_L_over_L',NaN, ...
    'Rc',NaN,'equation_relative',[NaN,NaN,NaN],'elapsed_seconds',0, ...
    'rhs_calls',0,'root_calls',0,'failure_reason','','x',[],'y',[], ...
    'shape',[],'energy',[],'diagnostics',[]);
end


function omegaL=frequency(Ba,p)
M=p.B_r*Ba/p.mu0;
e=fzero(@(e) p.C01*(2*e-2*e^(-2))+M,[.95,1.05]);
q=p.k*M*e^2/(2*p.C01-p.k^2*M*e^2);
omegaL=p.L*sqrt(p.b*p.h*M*e^5*(1+p.k*q)/(2*p.C01*p.I*(e^4+2*e)));
end

function write_table(cases,path,p)
fid=fopen(path,'w'); cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'Ba_mT,branch,converged,e0,X_L_over_L,v_L_over_L,phi_rad,phi_deg,theta_L,gamma_L,Utotal_J,delta_X_L_over_L,delta_v_L_over_L,delta_phi_rad,delta_phi_deg,delta_tip_distance_over_L,Rc,R34_rel,R35_rel,R36_rel,failure_reason\n');
for b=1:size(cases,2)
 last=[];
 [~,order]=sort([cases(:,b).Ba_mT]);
 for index=order
  c=cases(index,b); values=nan(1,8); deltas=nan(1,5);
  if c.converged
   values=[c.shape.X(end)/p.L,c.v_L_over_L,c.phi_L,c.phi_L*180/pi,c.theta_L,c.gamma_L,c.energy.Utotal,c.e0];
   if ~isempty(last)
    d=values(1:3)-last(1:3); deltas=[d,d(3)*180/pi,hypot(d(1),d(2))];
   end
   last=values;
  end
  reason=strrep(strrep(c.failure_reason,',',';'),sprintf('\n'),' ');
  fprintf(fid,'%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%s\n', ...
    c.Ba_mT,c.branch,c.converged,values(8),values(1:7),deltas,c.Rc,c.equation_relative,reason);
 end
end
end
