MATLAB structure-record compatibility fix

原因：MATLAB 拒绝向无字段的 struct([]) 按整结构下标赋值。
修复：第一条记录直接建立结构体字段，其后才按下标追加。
修复范围：validate_single_case 的 grid/tolerance 记录以及两个延拓程序的 history。
没有修改任何控制方程、初值、积分或求根容差、分支选择或已保存数据。

操作：
1. 先备份项目 source 中对应的三个 .m 文件。
2. 解压，将 source 中的三个文件复制到项目 source 文件夹，覆盖同名文件。
3. 将 resume_fig5_local.m 放到项目根目录，与 README.txt、source、data 同级。
4. MATLAB 运行 resume_fig5_local.m，选择包含 shooting_20mT.mat 的 rerun_fig5_... 文件夹。
5. 脚本从第二步继续验证，不重复第一步 shooting 全区间搜索；然后进行九场计算与绘图。
不要重新运行会执行 clear 和 shooting_solver 的旧 run_fig5_local.m。

此补丁的验证运行使用 Octave；当前云端没有原生 MATLAB。
继续脚本用于本地 MATLAB，云端未运行其交互选择和完整九场计算。
原完整项目 ZIP 保留不变，应先解压原包，再应用本补丁。
