function energy = energy_evaluation(x, e, gamma, theta, kappa, p)
%ENERGY_EVALUATION 按 Eq.(28)--(33) 计算无机械外力工况势能。
% 输入：完整轨迹 x、e、gamma、theta、kappa 及 p；允许降序网格。
% 输出：energy，Us、Um、Utotal [J]、升序 x 及两种能量密度 [J/m]。
% 用途：使用求解器输出的 kappa，以 trapz 在 0 到 L 积分。
validateattributes(x,{'numeric'},{'real','finite','vector','nonempty'});
n=numel(x); fields={e,gamma,theta,kappa};
for j=1:4
    validateattributes(fields{j},{'numeric'},{'real','finite','vector','numel',n});
end
if any(e<=0), error('HardMagneticBeam:EnergyStretch','能量计算要求 e>0。'); end
[x,order]=sort(x(:));
e=e(:); gamma=gamma(:); theta=theta(:); kappa=kappa(:);
e=e(order); gamma=gamma(order); theta=theta(order); kappa=kappa(order);
if n<2 || any(diff(x)<=0) || abs(x(1))>64*eps*max(1,p.L) ...
        || abs(x(end)-p.L)>64*eps*max(1,p.L)
    error('HardMagneticBeam:EnergyGrid','必须提供包含 0 和 L 的完整无重复网格。');
end
strain_density=p.C01*p.b*p.h*(e.^2+p.h^2*kappa.^2/12 ...
    +2./e+p.h^2*kappa.^2./(6*e.^3)-3 ...
    +gamma.^2.*(1./e+p.h^2*kappa.^2./(12*e.^3)));
magnetic_density=-(p.b*p.h/p.mu0)*p.B_r*p.B_a ...
    *e.*cos(theta+p.k*gamma-p.alpha);
Us=trapz(x,strain_density); Um=trapz(x,magnetic_density);
energy=struct('Us',Us,'Um',Um,'Utotal',Us+Um,'x',x, ...
    'strain_density',strain_density,'magnetic_density',magnetic_density);
end
