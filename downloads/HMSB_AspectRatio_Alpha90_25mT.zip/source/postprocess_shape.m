function shape = postprocess_shape(x, e, gamma, theta, p)
%POSTPROCESS_SHAPE 按 Eq.(91)--(92) 恢复含剪切的中心线。
% 输入：完整网格 x、e、gamma、theta 及 p，允许降序网格。
% 输出：shape，升序 x、u、v、X、Y、phi 列向量，v_L_over_L、phi_L。
% 用途：phi=theta+k*gamma，以 cumtrapz 积分满足 u(0)=v(0)=0。
% 位置单位 m，角度单位 rad；gamma 是剪切角，不是其导数。
validateattributes(x,{'numeric'},{'real','finite','vector','nonempty'});
n=numel(x);
validateattributes(e,{'numeric'},{'real','finite','vector','numel',n,'positive'});
validateattributes(gamma,{'numeric'},{'real','finite','vector','numel',n});
validateattributes(theta,{'numeric'},{'real','finite','vector','numel',n});
validateattributes(p.L,{'numeric'},{'real','finite','scalar','positive'});
validateattributes(p.k,{'numeric'},{'real','finite','scalar'});
[x,order]=sort(x(:)); e=e(:); gamma=gamma(:); theta=theta(:);
e=e(order); gamma=gamma(order); theta=theta(order);
if n<2 || any(diff(x)<=0) || abs(x(1))>64*eps*max(1,p.L) ...
        || abs(x(end)-p.L)>64*eps*max(1,p.L)
    error('HardMagneticBeam:ShapeGrid','必须提供包含 0 和 L 的完整无重复网格。');
end
phi=theta+p.k*gamma;
u=cumtrapz(x,e.*cos(phi)-1);
v=cumtrapz(x,e.*sin(phi));
shape=struct('x',x,'u',u,'v',v,'X',x+u,'Y',v,'phi',phi, ...
    'sort_order',order,'v_L_over_L',v(end)/p.L,'phi_L',phi(end));
end
