function [free_end, info, flag] = solve_free_end(e0, p)
%SOLVE_FREE_END 给定 e(L)=e0、kappa(L)=0 后求自由端状态。
% 输入：e0，自由端中心线伸长比；p，论文与算法参数结构体。
%       使用 p.L、C01、mu0、B_r、B_a、alpha、k、newton_tol、
%       newton_max_iter、newton_initial；所有数值应已在 parameters 中填写。
% 输出：free_end，含 x、e、gamma_tilde、theta、kappa 的自由端状态；
%       info，收敛状态、最终残差、迭代次数与记录；
%       flag，1=收敛，0=迭代超限，-1=非有限结果，-2=Jacobian 奇异
%       或在浮点精度下病态。失败时 free_end 为最后的有限迭代状态。
% 用途：从可配置初值出发，以给定解析 Jacobian 进行 Newton 更新。
%       alpha=pi 时 [0;0] 的 Jacobian 退化；初值是数值设置，不改方程。
% info.history 每行：[gamma_L, theta_L, 增量无穷范数, 残差无穷范数]，
% 保留原始 Newton 轨迹。收敛后选择离初始 theta 最近的等价 2*pi 周期，
% info.raw_theta 和 period_shift 记录该选择；不改变 gamma 或平衡方程。
% 调用者应检查 flag==1 后再进行反向推进。

validateattributes(e0, {'numeric'}, {'real', 'finite', 'scalar', 'positive'}, ...
    mfilename, 'e0');
validateattributes(p, {'struct'}, {'scalar'}, mfilename, 'p');
required = {'L', 'C01', 'mu0', 'B_r', 'B_a', 'alpha', 'k', ...
    'newton_tol', 'newton_max_iter'};
for j = 1:numel(required)
    name = required{j};
    if ~isfield(p, name)
        error('HardMagneticBeam:MissingParameter', ...
            '参数结构体缺少字段 p.%s。', name);
    end
    validateattributes(p.(name), {'numeric'}, ...
        {'real', 'finite', 'scalar'}, mfilename, ['p.' name]);
end
validateattributes(p.mu0, {'numeric'}, {'nonzero'}, mfilename, 'p.mu0');
validateattributes(p.newton_tol, {'numeric'}, {'positive'}, ...
    mfilename, 'p.newton_tol');
validateattributes(p.newton_max_iter, {'numeric'}, {'integer', 'positive'}, ...
    mfilename, 'p.newton_max_iter');
validateattributes(p.newton_initial, {'numeric'}, ...
    {'real', 'finite', 'vector', 'numel', 2}, mfilename, 'p.newton_initial');

x = p.newton_initial(:);        % x=[gamma_L; theta_L]，不是梁坐标
flag = 0;
info = struct('converged', false, 'residual', [], 'iterations', 0, ...
    'history', zeros(p.newton_max_iter, 4), 'message', '达到最大迭代次数。', ...
    'initial_guess', x, 'solution_phase', NaN, ...
    'acos_branch', 'unresolved', 'phase_period', NaN, ...
    'raw_theta', NaN, 'period_shift', 0);

for iter = 1:p.newton_max_iter
    [F, J] = free_end_equations(x, e0, p);
    if any(~isfinite(F)) || any(~isfinite(J(:)))
        flag = -1;
        info.message = '残差或 Jacobian 出现非有限值。';
        break;
    end
    % 恰好满足方程时，无需解可能奇异的 Jacobian。
    if all(F == 0)
        flag = 1;
        info.message = '自由端残差为零。';
        break;
    end
    if rcond(J) <= eps
        flag = -2;
        info.message = 'Jacobian 奇异或在浮点精度下病态。';
        break;
    end

    delta = J\F;
    xnew = x - delta;
    if any(~isfinite(delta)) || any(~isfinite(xnew))
        flag = -1;
        info.message = 'Newton 更新出现非有限值。';
        break;
    end
    Fnew = free_end_equations(xnew, e0, p);
    if any(~isfinite(Fnew))
        flag = -1;
        info.message = '更新后的自由端残差出现非有限值。';
        break;
    end

    step_norm = norm(xnew - x, inf);
    x = xnew;
    info.iterations = iter;
    info.history(iter, :) = [x.', step_norm, norm(Fnew, inf)];
    % 不除以当前 gamma 或 theta，允许初值为零。
    if step_norm <= p.newton_tol*(1 + norm(xnew, inf))
        flag = 1;
        info.message = '满足混合绝对/相对增量收敛判据。';
        break;
    end
end

info.raw_theta = x(2);
if flag == 1
    info.period_shift = round((x(2)-info.initial_guess(2))/(2*pi));
    x(2) = x(2) - 2*pi*info.period_shift;
    F = free_end_equations(x, e0, p);
    residual_limit = p.newton_tol*max([1, abs(p.C01), abs(p.B_r*p.B_a/p.mu0)]);
    if any(~isfinite(F)) || norm(F, inf) > residual_limit
        flag = -1;
        info.message = '周期分支选择后原方程残差不合格。';
    end
end
free_end = struct('x', p.L, 'e', e0, 'gamma_tilde', x(1), ...
    'theta', x(2), 'kappa', 0);
info.converged = (flag == 1);
info.flag = flag;
info.residual = free_end_equations(x, e0, p);
info.history = info.history(1:info.iterations, :);
if info.converged
    phase = x(2) + p.k*x(1) - p.alpha;
    info.solution_phase = phase;
    branch_sign = sign(sin(phase));
    if branch_sign > 0
        info.acos_branch = 'plus';
    elseif branch_sign < 0
        info.acos_branch = 'minus';
    else
        info.acos_branch = 'endpoint';
    end
    info.phase_period = round((phase - branch_sign*acos(cos(phase)))/(2*pi));
end
end

function [F, J] = free_end_equations(x, e0, p)
% 按给定公式计算残差与解析 Jacobian，列顺序为 gamma_L、theta_L。
gamma_L = x(1);
theta_L = x(2);
Theta = theta_L + p.k*gamma_L - p.alpha;

f1 = p.C01*(2*e0 - (gamma_L^2 + 2)*e0^(-2)) ...
    - (p.B_r*p.B_a/p.mu0)*cos(Theta);
f2 = 2*p.C01*e0^(-1)*gamma_L ...
    + (p.k*p.B_r*p.B_a/p.mu0)*e0*sin(Theta);
% 根据最新提供的 Eq.(35)，kappa(L)=0 后磁项必须带剪切系数 k。
F = [f1; f2];

J11 = (p.k*p.B_r*p.B_a/p.mu0)*sin(Theta) ...
    - 2*p.C01*e0^(-2)*gamma_L;
J12 = (p.B_r*p.B_a/p.mu0)*sin(Theta);
J21 = (p.k^2*p.B_r*p.B_a/p.mu0)*e0*cos(Theta) ...
    + 2*p.C01*e0^(-1);
J22 = (p.k*p.B_r*p.B_a/p.mu0)*e0*cos(Theta);
J = [J11, J12; J21, J22];
end
