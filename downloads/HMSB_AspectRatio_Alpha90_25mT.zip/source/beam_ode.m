function [dy, diagnostics] = beam_ode(x, y, p)
%BEAM_ODE 四状态梁方程，独立于有限差分及 acos 转角恢复。
% 输入：x [m]；y=[e;gamma;theta;kappa]；p，物理及 shooting 设置。
% 输出：dy=[e';gamma';kappa;kappa']；diagnostics，矩阵条件及线性残差。
% 用途：直接使用既有 build_system 与 theta'=kappa，不修改控制方程。
validateattributes(x, {'numeric'}, {'real', 'finite', 'scalar'}, mfilename, 'x');
validateattributes(y, {'numeric'}, {'real', 'vector', 'numel', 4}, mfilename, 'y');
y = y(:);
if any(~isfinite(y))
    error('HardMagneticBeam:ODEInvalidState', 'x=%.12g 的状态含 NaN/Inf。', x);
end
if y(1) <= 0
    error('HardMagneticBeam:ODEInvalidStretch', 'x=%.12g 处 e<=0。', x);
end
[A, rhs] = build_system(y(1), y(2), y(3), y(4), p);
if any(~isfinite(A(:))) || any(~isfinite(rhs))
    error('HardMagneticBeam:ODEInvalidMatrix', 'x=%.12g 的 A/rhs 含 NaN/Inf。', x);
end
raw_rcond = rcond(A);
% 附加无量纲平衡诊断，不改变实际求解矩阵或右端。
row_scale = max(abs(A), [], 2);
if any(row_scale == 0)
    scaled_rcond = 0;
else
    scaled = bsxfun(@rdivide, A, row_scale);
    col_scale = max(abs(scaled), [], 1);
    if any(col_scale == 0)
        scaled_rcond = 0;
    else
        scaled_rcond = rcond(bsxfun(@rdivide, scaled, col_scale));
    end
end
threshold = eps;
if isfield(p, 'shooting_rcond_min')
    threshold = p.shooting_rcond_min;
end
if ~isfinite(raw_rcond) || raw_rcond <= threshold
    error('HardMagneticBeam:ODEIllConditioned', ...
        'x=%.12g 的 A 奇异/病态：rcond=%.6g，平衡后诊断 rcond=%.6g。', ...
        x, raw_rcond, scaled_rcond);
end
der = A\rhs;
if any(~isfinite(der))
    error('HardMagneticBeam:ODEInvalidDerivative', 'x=%.12g 的导数含 NaN/Inf。', x);
end
dy = [der(1); der(2); y(4); der(3)];
diagnostics = struct('rcond', raw_rcond, 'scaled_rcond', scaled_rcond, ...
    'linear_residual', norm(A*der-rhs, inf));
end
