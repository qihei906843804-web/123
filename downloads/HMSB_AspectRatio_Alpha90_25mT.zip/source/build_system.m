function [A, rhs] = build_system(e, gamma, theta, kappa, p)
%BUILD_SYSTEM 按论文公式构造局部三元线性方程组。
% 输入：e，中心线伸长比；gamma，论文中的 gamma_tilde；
%       theta，转角 [rad]；kappa=dtheta/dx，曲率 [1/m]；
%       p，参数结构体，使用 C01、I、b、h、mu0、B_r、B_a、alpha、k。
%       状态和所用参数均为实数标量；e、mu0 必须非零。
% 输出：A，3x3 系数矩阵；rhs，3x1 右端向量。
% 用途：供后续通过 der = A\rhs 求解
%       der = [de/dx; dgamma/dx; d2theta/dx2]。
% 本函数仅组装矩阵，不使用 Cramer 法则，也不修改或正则化公式。

validateattributes(e, {'numeric'}, {'real', 'finite', 'scalar', 'nonzero'}, ...
    mfilename, 'e');
validateattributes(gamma, {'numeric'}, {'real', 'finite', 'scalar'}, ...
    mfilename, 'gamma');
validateattributes(theta, {'numeric'}, {'real', 'finite', 'scalar'}, ...
    mfilename, 'theta');
validateattributes(kappa, {'numeric'}, {'real', 'finite', 'scalar'}, ...
    mfilename, 'kappa');
validateattributes(p, {'struct'}, {'scalar'}, mfilename, 'p');
required = {'C01', 'I', 'b', 'h', 'mu0', 'B_r', 'B_a', 'alpha', 'k'};
for j = 1:numel(required)
    name = required{j};
    if ~isfield(p, name)
        error('HardMagneticBeam:MissingParameter', ...
            '参数结构体缺少字段 p.%s。', name);
    end
    validateattributes(p.(name), {'numeric'}, ...
        {'real', 'finite', 'scalar'}, mfilename, ['p.' name]);
end
validateattributes(p.mu0, {'numeric'}, {'nonzero'}, mfilename, 'p.mu0');

% B_r、B_a 存储磁通密度的模；k 与曲率 kappa 是不同变量。
C01 = p.C01;
I = p.I;
b = p.b;
h = p.h;
mu0 = p.mu0;
B_r = p.B_r;
B_a = p.B_a;
alpha = p.alpha;
k = p.k;

% 第一行及 b1。
a11 = -6*C01*I*(gamma^2 + 2)*kappa;
a12 = 4*C01*I*e*kappa*gamma;
a13 = 2*C01*I*(e^4 + (gamma^2 + 2)*e);
b1 = (b*h/mu0)*B_r*B_a*e^5*sin(theta + k*gamma - alpha);

% 第二行及 b2。
a21 = 2*C01*(1 + (gamma^2 + 2)*e^(-3) ...
    + ((gamma^2 + 2)/2)*h^2*kappa^2*e^(-5));
a22 = (B_r*B_a*k/mu0)*sin(theta + k*gamma - alpha) ...
    - 2*C01*gamma*(e^(-2) + (h^2*kappa^2/4)*e^(-4));
a23 = -C01*h^2*kappa*e^(-4)*(1 + gamma^2/2);
b2 = -(B_r*B_a/mu0)*sin(theta + k*gamma - alpha)*kappa;

% 第三行及 b3。
a31 = (b*h*k/mu0)*B_r*B_a*sin(theta + k*gamma - alpha) ...
    - 2*C01*gamma*e^(-2)*(b*h + 3*I*kappa^2*e^(-2));
a32 = 2*C01*e^(-1)*(b*h + I*kappa^2*e^(-2)) ...
    + (b*h*k^2/mu0)*B_r*B_a*e*cos(theta + k*gamma - alpha);
a33 = 4*C01*I*kappa*gamma*e^(-3);
b3 = -(b*h*k/mu0)*B_r*B_a*e*kappa*cos(theta + k*gamma - alpha);

A = [a11, a12, a13; ...
     a21, a22, a23; ...
     a31, a32, a33];
rhs = [b1; b2; b3];
end
