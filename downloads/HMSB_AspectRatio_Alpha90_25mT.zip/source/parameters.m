function p = parameters()
%PARAMETERS 集中管理论文参数与数值算法设置。
% 输入：无。
% 输出：p，包含物理参数、派生量及数值参数的结构体。
% 用途：集中设置参数，供自由端求解、反向推进与边界检查使用。
% 单位采用 SI；当前为 Fig.5 对应的单工况调试设置，Ba=20 mT。

p = struct();

% ---- 物理参数：在此填写或修改论文中的具体数值 ----
% 下列三个绝对尺寸仅为保持论文 L/h=20.5 而选取的复现尺度，
% 并非论文明确给出的实验尺寸。
p.h = 1e-3;          % 调试截面厚度 [m]
p.L = 20.5e-3;       % 调试梁长 [m]，L/h=20.5
p.b = 1e-3;          % 调试矩形截面宽度 [m]
p.G = 303e3;         % 论文剪切模量 [Pa]
p.mu0 = 4*pi*1e-7;   % 真空磁导率 [H/m]
p.B_r = 0.143;       % 论文 |B^r|，剩磁磁通密度的模 [T]
p.B_a = 20e-3;       % 本次单工况 |B^a| [T]，不扫描 0--40 mT
p.alpha = pi;        % 论文 alpha=180 度 [rad]
p.k = 1.2;           % 论文矩形截面剪切修正系数 [无量纲]，不是曲率

% ---- 派生物理量：按给定公式计算，不单独填写 ----
p.C01 = p.G / 2;                 % C_01 = G/2 [Pa]
p.I = p.b .* p.h.^3 / 12;       % I = b*h^3/12 [m^4]
% 对应输入为空时，派生量也保持为空。

% ---- 数值参数 ----
p.dx = p.L/100;                 % 101 节点的调试步长 [m]，不是论文给定值
% 后续需检查 N=101、201、401 的网格收敛；本次只用 101 节点。
p.Delta_e0 = 1e-6;               % 论文自由端搜索步长，供参考 [无量纲]
p.de0 = 1e-4;                   % 当前实际搜索步长；验证后可改为 1e-6
p.e0_range = [0.95, 1.05];       % 自由端伸长比搜索区间 [无量纲]
p.Delta_gamma = 0.02;            % Delta_gamma；单位及算法用途待论文确认
p.Delta_theta = 0.02;            % Delta_theta [rad]；算法用途待论文确认
p.Delta_c = 1e-2;                % 固定端角度残差容限 [rad]
% Delta_gamma、Delta_theta 不默认解释为 Newton 收敛容差。
% 以下为可修改的程序收敛设置，不是论文给定的物理参数。
p.newton_tol = 1e-10;            % 混合绝对/相对增量容差
p.newton_max_iter = 100;         % 最大 Newton 更新次数
p.newton_initial = [1e-3; 1e-3]; % [gamma_L;theta_L]；获准使用的对称破缺调试初值
% 不是论文给定值；可改回 [0;0] 复现 alpha=pi 的 Jacobian 退化。
p.theta_roundoff_tol = 64*eps;   % C 越界时仅允许舍入量级修正
p.eq34_residual_rtol = 256*eps;  % Eq.(34) 残差/方程项尺度容限
p.theta_branch_tol = 64*eps;     % 连续选支中判断等距的角度相对容限
% 正负初值可能选择不同分支，solve_free_end 会记录初值和结果分支。

% ---- 兼容现有框架的分组接口，均由上面的参数生成 ----
% 修改参数时请改上方赋值；这些分组在每次调用 parameters() 时同步。
p.geometry = struct('L', p.L, 'b', p.b, 'h', p.h, 'I', p.I);
p.material = struct('G', p.G, 'C01', p.C01);
p.magnetic = struct('mu0', p.mu0, 'B_r', p.B_r, ...
    'B_a', p.B_a, 'alpha', p.alpha);
p.boundary = struct('k', p.k, 'Delta_c', p.Delta_c);
p.numerics = struct('dx', p.dx, 'Delta_e0', p.Delta_e0, 'de0', p.de0, ...
    'e0_range', p.e0_range, 'Delta_gamma', p.Delta_gamma, ...
    'Delta_theta', p.Delta_theta, 'newton_tol', p.newton_tol, ...
    'newton_max_iter', p.newton_max_iter, 'newton_initial', p.newton_initial, ...
    'theta_roundoff_tol', p.theta_roundoff_tol, ...
    'eq34_residual_rtol', p.eq34_residual_rtol, ...
    'theta_branch_tol', p.theta_branch_tol);
end
