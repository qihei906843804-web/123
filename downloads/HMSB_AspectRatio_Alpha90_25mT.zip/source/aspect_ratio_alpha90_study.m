function study=aspect_ratio_alpha90_study(output_dir)
% Input: new output directory. Output: four continued shooting solutions.
% Fixed L, variable h; alpha=pi/2, Ba=25mT. No reflection of old branches.
assert(~exist(output_dir,'dir'),'Output already exists; preserving old results.');
mkdir(output_dir); timer=tic;
p=parameters(); p.L=20.5e-3; p.b=1e-3; p.alpha=pi/2; p.B_a=25e-3;
p.magnetic.alpha=p.alpha; p.magnetic.B_a=p.B_a;
ratios=[10,17.5,20.5,41]; cases=cell(4,1); history=struct([]);
previous=struct('e0',1,'gamma_L',0,'theta_L',0,'parameters',p);
previous.parameters.B_a=0;
% Start from the unloaded reference, rather than an alpha=pi branch.
for field=[.5,1,2,4,8,12,16,20,25]*1e-3
    c=attempt(20.5,field,previous);
    assert(c.converged,'Field continuation failed; see checkpoint.mat.');
    previous=c;
end
cases{3}=previous; anchor=previous;
for idx=[2,1]
    previous=advance(previous,ratios(idx)); cases{idx}=previous;
end
cases{4}=advance(anchor,41);
study=struct('parameters',p,'ratios',ratios,'cases',{cases}, ...
    'history',history,'elapsed_seconds',toc(timer),'stability_assessed',false, ...
    'RelTol',1e-8,'AbsTol',1e-10,'output_nodes',801, ...
    'branch_description','Continued from zero field toward +Y; no stability claim');
save(fullfile(output_dir,'aspect_ratio_alpha90.mat'),'study','-v7');
fid=fopen(fullfile(output_dir,'summary.csv'),'w'); cleanup=onCleanup(@()fclose(fid));
fprintf(fid,'L_over_h,h_m,Ba_T,alpha_rad,e0,theta_L,gamma_L,phi_rad,phi_deg,X_L_over_L,v_L_over_L,Rc,R34_rel,R35_rel,R36_rel,Us_J,Um_J,Utotal_J,worst_rcond,ode_identity,seconds\n');
for j=1:4
    c=cases{j}; assert(c.converged,'Missing converged target.');
    values=[ratios(j),c.parameters.h,c.parameters.B_a,c.parameters.alpha, ...
        c.e0,c.theta_L,c.gamma_L,c.phi_L,c.phi_L*180/pi, ...
        c.shape.X(end)/p.L,c.v_L_over_L,c.Rc,c.equation_relative, ...
        c.energy.Us,c.energy.Um,c.energy.Utotal,c.worst_rhs_rcond,c.ode_identity,c.elapsed_seconds];
    fprintf(fid,'%.17g',values(1)); fprintf(fid,',%.17g',values(2:end)); fprintf(fid,'\n');
    data=[c.x,c.y];
    out=fopen(fullfile(output_dir,sprintf('trajectory_ratio_%g.csv',ratios(j))),'w');
    fprintf(out,'x_m,e,gamma_rad,theta_rad,kappa_per_m\n');
    fprintf(out,'%.17g,%.17g,%.17g,%.17g,%.17g\n',data'); fclose(out);
    shape=c.shape;
    out=fopen(fullfile(output_dir,sprintf('shape_ratio_%g.csv',ratios(j))),'w');
    fprintf(out,'x_m,u_m,v_m,X_m,Y_m,phi_rad\n');
    fprintf(out,'%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n', ...
        [shape.x,shape.u,shape.v,shape.X,shape.Y,shape.phi]'); fclose(out);
end
fprintf('Completed in %.2fs; no stability assessment.\n',study.elapsed_seconds);

    function c=attempt(ratio,field,prev)
        q=p; q.h=q.L/ratio; q.I=q.b*q.h^3/12; q.B_a=field;
        q.geometry=struct('L',q.L,'b',q.b,'h',q.h,'I',q.I);
        q.magnetic.B_a=field;
        c=solve_hmsb_transverse_case(q,prev,1);
        record=struct('ratio',ratio,'Ba_T',field,'case',c);
        if isempty(history), history=record; else, history(end+1,1)=record; end
        save(fullfile(output_dir,'checkpoint.mat'),'history','cases','-v7');
        fprintf('Ba=%g mT L/h=%g success=%d Rc=%.3g phi=%.5g v/L=%.5g time=%.1fs\n', ...
            field*1e3,ratio,c.converged,c.Rc,c.phi_L,c.v_L_over_L,c.elapsed_seconds);
        if ~c.converged, fprintf('Reason: %s\n',c.failure_reason); end
    end
    function c=advance(prev,target)
        current=prev.parameters.L/prev.parameters.h;
        steps=linspace(current,target,ceil(abs(target-current)/2.5)+1);
        c=prev;
        for n=2:numel(steps)
            c=attempt(steps(n),p.B_a,c);
            assert(c.converged,'Geometry continuation failed; see checkpoint.mat.');
        end
    end
end
