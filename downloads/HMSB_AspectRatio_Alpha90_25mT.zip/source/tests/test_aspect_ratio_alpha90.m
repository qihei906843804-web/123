function test_aspect_ratio_alpha90(mat_file)
% Verify the saved transverse-field study without repeating the solver.
d=load(mat_file,'study'); s=d.study;
assert(isequal(s.ratios,[10,17.5,20.5,41]));
phis=zeros(1,4);
for j=1:4
    c=s.cases{j}; p=c.parameters;
    assert(c.converged && c.Rc<1e-7);
    assert(abs(p.L-20.5e-3)<eps && abs(p.B_a-.025)<eps);
    assert(abs(p.alpha-pi/2)<eps && abs(p.L/p.h-s.ratios(j))<1e-12);
    assert(abs(p.I-p.b*p.h^3/12)<eps*p.I);
    assert(all(c.equation_relative<1e-6));
    assert(c.x(1)==p.L && c.x(end)==0 && c.y(1,4)==0);
    assert(c.ode_identity==0 && c.worst_rhs_rcond>eps);
    assert(c.shape.X(1)==0 && c.shape.Y(1)==0);
    assert(c.phi_L>0 && c.phi_L<pi/2 && c.v_L_over_L>0);
    assert(all(c.y(:,4)>-1e-5)); % excludes extra-turn shooting trajectories
    check=postprocess_shape(c.x,c.y(:,1),c.y(:,2),c.y(:,3),p);
    assert(abs(check.v_L_over_L-c.v_L_over_L)<1e-12);
    phis(j)=c.phi_L;
end
assert(all(diff(phis)>0));
fprintf('PASS: four transverse-field targets, equations, boundary conditions and fundamental curvature branch.\n');
end
