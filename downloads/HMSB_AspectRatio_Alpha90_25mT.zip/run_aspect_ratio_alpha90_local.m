% Run this script from the extracted project's root directory in MATLAB.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'source')); addpath(root);
outputDir=fullfile(root,['aspect_ratio_alpha90_25mT_' datestr(now,'yyyymmdd_HHMMSS')]);
study=aspect_ratio_alpha90_study(outputDir);
fig=plot_aspect_ratio_alpha90(study,fullfile(outputDir,'figures'),1);
fprintf('Results and figures: %s\n',outputDir);
