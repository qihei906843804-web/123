HARD-MAGNETIC SOFT BEAM: FIXED LENGTH / VARIABLE THICKNESS

MATLAB RUN INSTRUCTIONS
1. Extract this entire ZIP into a new directory.
2. In MATLAB select that directory as Current Folder.
3. Open run_aspect_ratio_alpha90_local.m and click Run, or type:
   run_aspect_ratio_alpha90_local
This recomputes the shooting solutions and exports a PNG (300 dpi), PDF and
native MATLAB FIG to a new timestamped output directory. No pre-existing
Fig.5 sweep MAT is required. MATLAB runtime has not been available here;
these functions and their numerical results were verified with Octave 9.4.

To plot already calculated results without solving again:
   addpath('source')
   d = load(fullfile('example_results','aspect_ratio_alpha90.mat'));
   plot_aspect_ratio_alpha90(d.study, 'replot_figures', 1);
The output directory must not exist. Preserve original results.

PARAMETERS
G=303000 Pa; Br=0.143 T; Ba=0.025 T; alpha=pi/2 rad; k=1.2;
mu0=4*pi*1e-7 H/m; fixed L=0.0205 m; b=0.001 m.
L/h=10,17.5,20.5,41; h=L/(L/h); C01=G/2; I=b*h^3/12.
These absolute dimensions are chosen reproduction scales, not reported
experimental dimensions. The magnetic coefficient Br*Ba/(G*mu0) is about
0.00938909; the screenshot uses 0.0094 (25.0290467mT with these materials).
This package follows the requested EXACT 25mT.

METHOD
Four-state y=[e,gamma,theta,kappa]. beam_ode uses build_system and theta'=kappa.
No acos reconstruction of theta. Original finite difference files remain
unchanged in the original project. Start at the zero-field undeformed state,
continue fields 0.5,1,2,4,8,12,16,20,25mT at L/h=20.5, then continue geometry
with maximum L/h step 2.5. This follows the +Y fundamental bending branch;
tip tangent must remain between 0 and alpha. This branch selection is
explicit, and neither uniqueness nor stability is established. No mirrored
negative branch is assumed for alpha=90deg.
ODE45 RelTol=1e-8, AbsTol=1e-10; MaxStep=L/10. Output nodes=801 (not internal
ODE steps). Root target Rc<1e-7rad; original boundary criterion Delta_c=0.01.
Normalized residual scales Eq34:G; Eq35:G*b*h; Eq36:G*I/L^2.
Record singularity/failure and stop rather than replace a branch or fabricate
missing results. All continuation trial failures are in the MAT history.

FILES
source/aspect_ratio_alpha90_study.m : parameter continuation and exports
source/solve_hmsb_transverse_case.m : free-end Newton + ODE + e0 root
source/plot_aspect_ratio_alpha90.m : equal-scale beam panels from saved data
source/parameters.m : original defaults; study overrides alpha/Ba/geometry
source/build_system.m : unchanged paper derivative equations
source/solve_free_end.m : unchanged free-end Newton equations
source/beam_ode.m, beam_residuals.m : states and original equation checks
source/postprocess_shape.m : paper centerline kinematics including k*gamma
source/energy_evaluation.m : paper strain and magnetic energies
source/tests/test_aspect_ratio_alpha90.m : saved-result consistency checks
example_results/: full MAT and 17-digit CSV; checkpoint contains intermediate
field/geometry cases, root trials and failure reasons. PNG/PDF and Octave
.ofig in figures/; .ofig is not a MATLAB FIG. Running in MATLAB creates FIG.

PLOT INTERPRETATION
Solid blue thickness bands are visualization approximations using constant
h along the centerline normal. Dashed yellow lines are computed centerlines.
No experimental comparison or stability validation is claimed.

REFINEMENT RECORD
The first L/h=41 candidate met the paper criterion but missed the extra
1e-7rad root target (Rc=2.75e-7rad). Preserved in
aspect_ratio_alpha90_before_refinement.mat and initial_exports/summary.csv.
Root search and final trajectory now use identical 801-node output schedules
to avoid Octave initial-step differences. Refined Rc=8.205e-9rad, with the
same original equations and tolerances. Other targets did not need refinement.
