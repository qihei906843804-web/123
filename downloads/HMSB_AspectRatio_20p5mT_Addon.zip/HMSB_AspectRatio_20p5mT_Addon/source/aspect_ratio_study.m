function study = aspect_ratio_study(anchor_file, output_dir)
%ASPECT_RATIO_STUDY 固定 L=20.5mm、Ba=20.5mT，改变 h；独立保留双分支。
% 输入：已有完整 Fig.5 sweep.mat；全新输出目录。无云端路径依赖。
% 输出：study；四个目标工况、全部中间延拓/失败、MAT 与17位精度 CSV。
if exist(output_dir,'dir'), error('HMSB:PreserveResults','输出目录已存在，拒绝覆盖。'); end
saved=load(anchor_file,'sweep'); a=saved.sweep;
index=find(abs(a.fields_mT-20)<1e-12,1);
assert(~isempty(index),'基线没有 20mT 状态。');
p=parameters(); p.L=20.5e-3; p.b=1e-3; p.B_a=20.5e-3;
p.magnetic.B_a=p.B_a;
ratios=[10,17.5,20.5,41]; timer=tic; mkdir(output_dir);
history=struct([]); targets=cell(4,2); anchor=cell(1,2);
for branch=1:2
    old=a.cases(index,branch); assert(old.converged,'基线分支未收敛。');
    old.parameters=a.parameters; old.parameters.B_a=20e-3;
    anchor{branch}=attempt(20.5,old,branch);
    assert(anchor{branch}.converged,'20.5mT 锚点未收敛，记录已保存。');
    targets{3,branch}=anchor{branch};
end
% 每条分支分别从基准向两侧延拓，最大长厚比步长 2.5。
for branch=1:2
    previous=anchor{branch};
    for idx=[2,1]
        previous=advance(previous,ratios(idx),branch,0);
        targets{idx,branch}=previous;
        if ~previous.converged, break; end
    end
    previous=advance(anchor{branch},41,branch,0); targets{4,branch}=previous;
end
study=struct('parameters',p,'ratios',ratios,'cases',{targets},'history',history, ...
    'fixed_length',true,'elapsed_seconds',toc(timer),'anchor_file',anchor_file, ...
    'RelTol',1e-8,'AbsTol',1e-10,'output_nodes',801,'stability_assessed',false);
save(fullfile(output_dir,'aspect_ratio_study.mat'),'study','-v7');
export_summary(study,fullfile(output_dir,'summary.csv'));
fprintf('几何系列完成：%.2f秒；未判断分支稳定性。\n',study.elapsed_seconds);

    function c=attempt(ratio,previous,branch)
        local=p; local.h=local.L/ratio; local.I=local.b*local.h^3/12;
        local.C01=local.G/2; local.dx=local.L/100;
        local.geometry=struct('L',local.L,'b',local.b,'h',local.h,'I',local.I);
        local.magnetic.B_a=local.B_a; local.numerics.dx=local.dx;
        if branch==2 && ~isempty(history)
            found=find(abs([history.ratio]-ratio)<1e-12 & [history.branch]==1,1,'last');
            if ~isempty(found) && history(found).case.converged
                local.continuation_e0_guess=history(found).case.e0;
            end
        end
        c=solve_hmsb_case(local,previous,branch);
        record=struct('ratio',ratio,'branch',branch,'case',c);
        if isempty(history), history=record; else, history(end+1,1)=record; end
        save(fullfile(output_dir,'checkpoint.mat'),'history','targets','-v7');
        fprintf('L/h=%g branch=%d: success=%d Rc=%g phi=%g v/L=%g time=%.2fs\n', ...
            ratio,branch,c.converged,c.Rc,c.phi_L,c.v_L_over_L,c.elapsed_seconds);
        if ~c.converged, fprintf('  原因：%s\n',c.failure_reason); end
        if c.converged && ~c.root_target_met
            fprintf('  Rc 通过论文 Delta_c，但未达到额外的 1e-7 rad 根目标。\n');
        end
    end
    function c=advance(previous,target,branch,depth)
        if ~previous.converged, c=previous; return; end
        current=previous.parameters.L/previous.parameters.h;
        if abs(target-current)<1e-12, c=previous; return; end
        next=current+sign(target-current)*min(2.5,abs(target-current));
        c=attempt(next,previous,branch);
        if ~c.converged
            if depth>=6 || abs(next-current)<0.05, return; end
            midpoint=(current+next)/2;
            middle=advance(previous,midpoint,branch,depth+1);
            if ~middle.converged, c=middle; return; end
            c=advance(middle,target,branch,depth+1);
        elseif abs(next-target)>1e-12
            c=advance(c,target,branch,0);
        end
    end
end

function export_summary(study,path)
fid=fopen(path,'w'); assert(fid>=0,'无法创建 summary.csv');
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'L_over_h,branch,converged,root_target_met,L_m,h_m,b_m,Ba_T,e0,theta_L,gamma_L,phi_rad,phi_deg,X_L_over_L,v_L_over_L,Rc,R34_rel,R35_rel,R36_rel,Us_J,Um_J,Utotal_J,worst_rhs_rcond,seconds,failure_reason\n');
for j=1:numel(study.ratios)
 for b=1:2
    c=study.cases{j,b};
    if isempty(c)
        fprintf(fid,'%.17g,%d,0,0,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,NaN,"未求解：前一延拓失败"\n',study.ratios(j),b);
        continue;
    end
    values=nan(1,24); p=c.parameters;
    values(1:13)=[study.ratios(j),b,c.converged,c.root_target_met,p.L,p.h,p.b,p.B_a, ...
        c.e0,c.theta_L,c.gamma_L,c.phi_L,c.phi_L*180/pi];
    values(15:19)=[c.v_L_over_L,c.Rc,c.equation_relative];
    values(23:24)=[c.worst_rhs_rcond,c.elapsed_seconds];
    if c.converged
        values(14)=c.shape.X(end)/p.L;
        values(20:22)=[c.energy.Us,c.energy.Um,c.energy.Utotal];
    end
    fprintf(fid,'%.17g,',values);
    fprintf(fid,'"%s"\n',strrep(c.failure_reason,'"','""'));
    if c.converged
        out=fopen(fullfile(fileparts(path),sprintf('shape_ratio_%g_branch%d.csv',study.ratios(j),b)),'w');
        assert(out>=0,'无法创建形状 CSV');
        fprintf(out,'x_m,e,gamma_rad,theta_rad,kappa_per_m,X_m,Y_m,u_m,v_m,phi_rad\n');
        [~,order]=sort(c.x); state=c.y(order,:); s=c.shape;
        fprintf(out,'%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n', ...
            [s.x,state,s.X,s.Y,s.u,s.v,s.phi]'); fclose(out);
    end
 end
end
end
