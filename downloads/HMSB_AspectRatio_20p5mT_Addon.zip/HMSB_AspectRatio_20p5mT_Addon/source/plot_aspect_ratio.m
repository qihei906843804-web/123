function fig = plot_aspect_ratio(study, output_dir, branch)
%PLOT_ASPECT_RATIO 四个长厚比的等比例并排梁形；不再次计算。
% 输入：study；全新图目录；branch=1正、2负（显示选择，不代表稳定性）。
% 输出：figure。带厚度轮廓为恒定 h 的中心线法向绘图近似。
if nargin<3, branch=1; end
assert(ismember(branch,[1,2]),'branch 必须为 1 或 2。');
if exist(output_dir,'dir'), error('HMSB:PreserveFigures','图目录已存在，拒绝覆盖。'); end
mkdir(output_dir); bounds=[Inf,-Inf,Inf,-Inf];
for j=1:numel(study.ratios)
    c=study.cases{j,branch};
    if isempty(c) || ~c.converged, continue; end
    s=c.shape; half=c.parameters.h/(2*c.parameters.L);
    xx=s.X/c.parameters.L; yy=s.Y/c.parameters.L;
    bounds=[min(bounds(1),min(xx)-half),max(bounds(2),max(xx)+half), ...
        min(bounds(3),min(yy)-half),max(bounds(4),max(yy)+half)];
end
assert(all(isfinite(bounds)),'没有可绘制的收敛工况。');
margin=.08*max(bounds(2)-bounds(1),bounds(4)-bounds(3));
fig=figure('Color','w','Name','Fixed length, Ba = 20.5 mT', ...
    'Position',[60,100,1350,360]);
set(fig,'PaperUnits','inches','PaperPosition',[0,0,13.5,3.6],'PaperSize',[13.5,3.6]);
for j=1:numel(study.ratios)
    subplot(1,numel(study.ratios),j); hold on;
    c=study.cases{j,branch};
    if isempty(c) || ~c.converged
        text(.5,.5,'NOT CONVERGED','Units','normalized','HorizontalAlignment','center');
    else
        s=c.shape; L=c.parameters.L; h=c.parameters.h;
        nx=-sin(s.phi); ny=cos(s.phi);
        xx=[s.X+h*nx/2;flipud(s.X-h*nx/2)]/L;
        yy=[s.Y+h*ny/2;flipud(s.Y-h*ny/2)]/L;
        patch(xx,yy,[.22,.18,.65],'EdgeColor','none');
        plot(s.X/L,s.Y/L,'--','Color',[.96,.88,.20],'LineWidth',1.15);
        plot(0,0,'ko','MarkerSize',3,'MarkerFaceColor','k');
    end
    axis equal;
    xlim(bounds(1:2)+[-margin,margin]); ylim(bounds(3:4)+[-margin,margin]);
    axis off;
    text(.5,-.04,sprintf('L/h = %g',study.ratios(j)), ...
        'Units','normalized','HorizontalAlignment','center','FontSize',12);
end
annotation(fig,'textbox',[.04,.93,.92,.06],'String', ...
    'L = 20.5 mm; B_a = 20.5 mT; alpha = pi; approximate thickness bands', ...
    'EdgeColor','none','HorizontalAlignment','center','FontSize',11);
print(fig,fullfile(output_dir,'AspectRatio_BeamShapes.png'),'-dpng','-r300');
print(fig,fullfile(output_dir,'AspectRatio_BeamShapes.pdf'),'-dpdf');
if exist('OCTAVE_VERSION','builtin')
    hgsave(fig,fullfile(output_dir,'AspectRatio_BeamShapes.ofig'));
else
    savefig(fig,fullfile(output_dir,'AspectRatio_BeamShapes.fig'));
end
end
