function c = solve_hmsb_case(p, previous, branch)
%SOLVE_HMSB_CASE 沿已知非零分支进行单工况四状态 shooting。
% 输入：p；上一工况 previous（含 e0/gamma_L/theta_L）；branch=1正、2负。
% 输出：完整轨迹、原方程/条件数诊断、根试探；不改变已有控制方程。
% 数值根目标 1e-7 rad 与论文 Delta_c 分开记录，不掩盖机器精度限制。
timer=tic; seed=[previous.gamma_L;previous.theta_L];
values=[]; residuals=[]; trials=struct([]); root_calls=0;
M=p.B_r*p.B_a/p.mu0;
low=fzero(@(e) p.C01*(2*e-2*e^(-2))+M,[.95,1]);
high=fzero(@(e) p.C01*(2*e-2*e^(-2))-M,[1,1.05]);
guess=previous.e0;
if isfield(previous,'parameters') && previous.parameters.B_a>0
    guess=1+(guess-1)*p.B_a/previous.parameters.B_a;
end
% 对称支可复用已求出的伸长比作为猜测；仍独立 Newton/ODE 求解。
if isfield(p,'continuation_e0_guess'), guess=p.continuation_e0_guess; end
[v,ok]=evaluate(guess);
if ok && abs(v)<1e-7
    e0=guess; root_flag=1;
else
    center=(guess-low)/(high-low);
    fractions=[center+[-.0001,.0001,-.001,.001,-.003,.003,-.008,.008], ...
        1-logspace(-2,-11,10), ...
        center+[-.015,.015,-.04,.04,-.1,.1,-.2,.2,-.4,.4],linspace(.001,.999,17)];
    fractions=fractions(fractions>1e-12 & fractions<1-1e-12);
    bracket=[];
    for fraction=fractions
        evaluate(low+fraction*(high-low));
        [sorted,order]=sort(values); r=residuals(order);
        crossing=find(r(1:end-1).*r(2:end)<0);
        if ~isempty(crossing)
            [~,which]=min(abs((sorted(crossing)+sorted(crossing+1))/2-guess));
            j=crossing(which); bracket=[sorted(j),sorted(j+1)]; break;
        end
    end
    if isempty(bracket)
        c=empty_case(); c.parameters=p; c.branch=branch; c.trials=trials;
        c.failure_reason='所追踪分支未找到有效边界变号区间。';
        c.elapsed_seconds=toc(timer); return;
    end
    try
        [e0,~,root_flag]=fzero(@required_value,bracket,optimset('TolX',eps));
    catch exception
        c=empty_case(); c.parameters=p; c.branch=branch; c.trials=trials;
        c.failure_reason=exception.message; c.elapsed_seconds=toc(timer); return;
    end
end
try
    [x,y,info]=integrate_case(e0,true);
    c=empty_case(); c.parameters=p; c.branch=branch;
    c.e0=e0; c.gamma_L=y(1,2); c.theta_L=y(1,3);
    c.x=x; c.y=y; c.newton_info=info.newton;
    c.shape=postprocess_shape(x,y(:,1),y(:,2),y(:,3),p);
    c.energy=energy_evaluation(x,y(:,1),y(:,2),y(:,3),y(:,4),p);
    c.phi_L=c.shape.phi_L; c.v_L_over_L=c.shape.v_L_over_L;
    c.Rc=abs(y(end,3)+p.k*y(end,2));
    c.diagnostics=beam_residuals(x,y,p);
    c.equation_relative=c.diagnostics.max_relative;
    c.root_target_met=(c.Rc<1e-7);
    c.converged=root_flag>0 && c.Rc<=p.Delta_c && all(c.equation_relative<1e-6);
    c.rhs_calls=info.rhs_calls; c.worst_rhs_rcond=info.worst_rcond;
    c.ode_identity=info.ode_identity;
    if ~c.converged, c.failure_reason='根、固定端或原始方程残差未通过。'; end
catch exception
    c=empty_case(); c.parameters=p; c.branch=branch; c.failure_reason=exception.message;
end
c.trials=trials; c.root_calls=root_calls; c.elapsed_seconds=toc(timer);

    function [value,success]=evaluate(e)
        root_calls=root_calls+1; value=NaN; success=false;
        record=struct('e0',e,'seed',seed,'success',false,'signed_Rc',NaN,'failure_reason','');
        try
            [~,state,~]=integrate_case(e,false);
            value=state(end,3)+p.k*state(end,2); success=true;
            values(end+1)=e; residuals(end+1)=value;
            record.success=true; record.signed_Rc=value;
        catch exception
            record.failure_reason=exception.message;
        end
        if isempty(trials), trials=record; else, trials(end+1,1)=record; end
    end
    function value=required_value(e)
        [value,success]=evaluate(e);
        if ~success, error('HMSB:InvalidRootTrial','根细化试探失败，详见 trials。'); end
    end
    function [x,state,info]=integrate_case(e,dense)
        local=p; local.newton_initial=seed;
        [f,ninfo,flag]=solve_free_end(e,local);
        if flag~=1, error('HMSB:NewtonFailure','Newton 失败：%s',ninfo.message); end
        if (branch==1 && (f.theta<=0 || f.theta>=pi)) || ...
           (branch==2 && (f.theta>=0 || f.theta<=-pi))
            error('HMSB:BranchChanged','自由端角度离开追踪的基本弯曲分支。');
        end
        options=odeset('RelTol',1e-8,'AbsTol',1e-10,'MaxStep',p.L/10);
        calls=0; worst=Inf; identity=0;
        if dense
            [x,state]=ode45(@rhs,linspace(p.L,0,801),[f.e;f.gamma_tilde;f.theta;0],options);
        else
            sol=ode45(@rhs,[p.L,0],[f.e;f.gamma_tilde;f.theta;0],options);
            x=sol.x(:); state=sol.y';
        end
        if x(end)~=0 || any(~isfinite(state(:))) || any(state(:,1)<=0)
            error('HMSB:IntegrationFailure','积分未完成或出现无效状态。');
        end
        info=struct('newton',ninfo,'rhs_calls',calls,'worst_rcond',worst,'ode_identity',identity);
        function dy=rhs(x,y)
            calls=calls+1;
            if calls>10000, error('HMSB:RHSLimit','积分超过 10000 次 RHS 调用。'); end
            [dy,d]=beam_ode(x,y,local);
            worst=min(worst,d.rcond); identity=max(identity,abs(dy(3)-y(4)));
        end
    end
end

function c=empty_case()
c=struct('parameters',[],'branch',NaN,'converged',false,'root_target_met',false, ...
 'e0',NaN,'theta_L',NaN,'gamma_L',NaN,'phi_L',NaN,'v_L_over_L',NaN, ...
 'Rc',NaN,'equation_relative',[NaN,NaN,NaN],'elapsed_seconds',0,'root_calls',0, ...
 'rhs_calls',0,'worst_rhs_rcond',NaN,'ode_identity',NaN,'failure_reason','', ...
 'x',[],'y',[],'shape',[],'energy',[],'diagnostics',[],'newton_info',[],'trials',struct([]));
end
