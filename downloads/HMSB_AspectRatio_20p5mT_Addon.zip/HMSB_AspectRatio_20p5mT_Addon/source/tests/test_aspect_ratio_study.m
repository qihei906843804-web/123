function test_aspect_ratio_study(path)
%TEST_ASPECT_RATIO_STUDY 检查已保存几何扫描，不重新积分。
if nargin<1, path='/workspace/123/results/aspect_ratio_20p5mT/aspect_ratio_study.mat'; end
s=load(path,'study'); r=s.study;
assert(isequal(r.ratios,[10,17.5,20.5,41]) && ~r.stability_assessed);
assert(r.fixed_length && r.output_nodes==801 && r.RelTol==1e-8 && r.AbsTol==1e-10);
for j=1:4
 for b=1:2
    c=r.cases{j,b}; p=c.parameters;
    assert(c.converged && isempty(c.failure_reason));
    assert(p.L==20.5e-3 && p.b==1e-3 && p.B_a==20.5e-3);
    assert(abs(p.h-p.L/r.ratios(j))<eps);
    assert(abs(p.I-p.b*p.h^3/12)<eps*p.I);
    assert(p.geometry.h==p.h && p.geometry.I==p.I && p.magnetic.B_a==p.B_a);
    assert(all(c.equation_relative<1e-6) && c.Rc<=p.Delta_c);
    assert(numel(c.x)==801 && c.x(1)==p.L && c.x(end)==0);
    assert(c.y(1,4)==0 && c.ode_identity==0);
    assert(all(c.y(:,1)>0) && all(isfinite(c.y(:))));
    assert(c.shape.x(1)==0 && c.shape.x(end)==p.L);
    assert(c.shape.u(1)==0 && c.shape.v(1)==0);
    assert(abs(c.Rc-abs(c.y(end,3)+p.k*c.y(end,2)))<eps);
    % 基本弯曲分支的曲率不反号，不把多波形解混入同一展示分支。
    if b==1, assert(min(c.y(:,4))>=-1e-6);
    else, assert(max(c.y(:,4))<=1e-6); end
 end
 a=r.cases{j,1}; z=r.cases{j,2};
 assert(abs(a.phi_L+z.phi_L)<1e-7);
 assert(abs(a.v_L_over_L+z.v_L_over_L)<1e-6);
 assert(max(abs(a.shape.X-z.shape.X))/a.parameters.L<1e-6);
 assert(abs(a.energy.Utotal-z.energy.Utotal)<1e-12);
end
angles=cellfun(@(c)c.phi_L,r.cases(:,1)); assert(all(diff(angles)>0));
fprintf('PASS: 固定 L/Ba、变化 h/I、八个独立分支、原方程、曲率方向及镜像检查。\n');
end
