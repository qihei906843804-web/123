固定长度、改变厚度：Ba=20.5 mT 的四工况独立扩展

固定：L=20.5 mm、b=1 mm、Ba=20.5 mT、G=303e3 Pa、Br=0.143 T、alpha=pi、k=1.2。
L/h=[10,17.5,20.5,41]；h 分别为 [2.05,1.1714285714285714,1,0.5] mm。
每个工况重新计算 I=b*h^3/12。原 parameters.m、build_system.m、beam_ode.m 等不作修改。
alpha=pi 沿用已验证模型，不为模仿示意图而旋转外磁场或改变方程。

安装与运行（原项目已解压，含 source 和 data）：
1. 将本扩展中的 run_aspect_ratio_local.m 复制到原项目根目录，与 README.txt 同级。
2. 将本扩展 source 文件夹内的三个 .m 文件复制到原项目 source 文件夹。
   它们是新文件，不需要替换原模型文件。tests 文件可选复制。
3. 在 MATLAB 中打开 run_aspect_ratio_local.m，点击绿色“运行”。
4. 程序从包中验证过的 20mT、L/h=20.5 双分支出发，先重算 20.5mT 锚点，
   再向低/高长厚比延拓。中间几何工况用于保持分支连续，不只是画四条旧线。
5. 新结果保存在项目根目录的 aspect_ratio_20p5mT_时间戳 文件夹。

扩展文件用途：
run_aspect_ratio_local.m  本地入口，无云端硬编码数据路径。
source/aspect_ratio_study.m  固定长度几何延拓，保留所有中间工况和失败；自动减小失败步长。
source/solve_hmsb_case.m  复用既有 solve_free_end/beam_ode 的四状态 shooting。
source/plot_aspect_ratio.m  四子图同一比例、统一坐标范围，蓝色厚度带、黄色虚线中心线。
source/tests/test_aspect_ratio_study.m  仅读取保存的几何系列，检查模型参数/分支/残差。

数值设置：ode45；RelTol=1e-8；标量AbsTol=1e-10；MaxStep=L/10；801输出节点。
根求解 fzero TolX=eps，记录额外的 root_target_met（Rc<1e-7 rad）。
论文固定端接受条件仍为 Rc<=Delta_c=1e-2 rad，另要求三式最大归一化残差<1e-6。
严格根目标和论文边界条件分开记录，若前者未达会打印说明，不隐藏实际残差。
最大长厚比延拓步长2.5，失败时减半；不自动更换正负分支使曲线平滑。
负支可以用同工况正支的 e0 作初猜，但其 Newton 和 ODE 独立计算，不复制镜像轨迹。

输出：
aspect_ratio_study.mat  四个目标工况的八条独立分支及所有延拓试探。
checkpoint.mat  中间记录，可检查失败原因。
summary.csv  h、L、I相关工况、端点、位移、能量、残差、条件数及时间（%.17g）。
shape_ratio_*_branch*.csv  完整升序坐标的十列状态和中心线（%.17g）。
figures/AspectRatio_BeamShapes.png  300dpi四子图。
figures/AspectRatio_BeamShapes.pdf  矢量/混合PDF。
figures/AspectRatio_BeamShapes.fig  在原生MATLAB中由savefig生成的可编辑图。
Octave 测试生成的是 .ofig；本扩展不将 .ofig 冒充原生 MATLAB FIG。

默认显示正支；完整数据同时保存负支。若要单独显示负支，可读取study并执行：
  plot_aspect_ratio(study,fullfile(outputDir,'figures_negative'),2);
选择显示正支不代表判断其稳定，也没有穷尽全部物理解。
蓝色厚度带为中心线法向恒定 h 的可视化近似，不是新增截面变形模型。
同一坐标比例且不旋转梁形；与示意图形状的差异应检查磁场方向与边界条件，不能强制绘图匹配。

example_results 是当前云端 Octave 计算的示例数据。入口仍会重新计算，而非读取示例图片。
当前无原生 MATLAB 环境；计算和绘图在 Octave 验证，不声称已执行本地 MATLAB GUI。

云端结果验证：八个目标分支全部通过；最大固定端 Rc=1.84333e-8 rad。
Eq.(34)–(36) 最大归一化残差为 2.03442e-10、8.70698e-10、5.77440e-14。
已检查镜像、曲率方向、固定L/Ba和变化h/I。未判断稳定性。
study.cases 是 4×2 cell，行顺序 [10,17.5,20.5,41]，列为正/负支，用花括号索引。
例：S=load('example_results/aspect_ratio_study.mat'); c=S.study.cases{3,1};
每个工况 c.parameters 为该工况实际使用的参数；不要用基准参数的 h/I 代替它。
