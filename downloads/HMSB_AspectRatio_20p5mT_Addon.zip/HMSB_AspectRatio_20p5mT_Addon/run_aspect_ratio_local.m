% RUN_ASPECT_RATIO_LOCAL 固定长度、改变厚度，重新计算四个几何工况。
% 放在项目根目录，与 README.txt、source、data 同级，点击“运行”。
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'source'));
anchorFile=fullfile(root,'data','beam-results','fig5a_sweep_complete','sweep.mat');
assert(exist(anchorFile,'file')==2,'找不到已有 Fig.5 MAT，请确认脚本位于项目根目录。');
outputDir=fullfile(root,['aspect_ratio_20p5mT_' datestr(now,'yyyymmdd_HHMMSS')]);
study=aspect_ratio_study(anchorFile,outputDir);
% 正、负分支都保存。这里选择正分支显示，不判断其稳定性。
fig=plot_aspect_ratio(study,fullfile(outputDir,'figures'),1);
fprintf('\n完整数值数据、双分支、CSV 和图片保存在：\n%s\n',outputDir);
